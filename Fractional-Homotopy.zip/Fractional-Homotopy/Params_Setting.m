   %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%     %% Global constants
%     global x0_guess;              % Initial guess for costates
%     global solver_tol;            % Tolerance 
%     global max_norm_x;            % Maximum value of norm(x), to avoid the 
%                                   % intermediate solution goes to infinity
%     global frac_int_flag;         % Fractional order integration flag, 
%                                   % 1: fractional order, 0: integer order
%     global frac_step;             % Fractional order integration step, if  frac_int_flag = 1;
    
    x1_0 = 0;
    x2_0 = -1.0;
    x3_0 = -1.0;

    x1_f = 0;
    x2_f = 0;
    x3_f = 0;
    
    
    
    Unknowns_Dim = 4;
    ODE_DIM   = 6;
    
    Unknowns_guess = [-0.5;3.0;5.0;8.0;];
    solver_tol = 1.0e-10;

    max_norm_x = 1.0e3;

    frac_int_flag = 1;   % 1: fractional order integration 0: rk45
    B_beta_flag = 6;     % only valid when frac_int_flag =1
                         % 1: B(k) = 1
                         % 2: B(k) = 0.9 + 0.1 cos(k pi)
                         % 3: B(k) = 0.8 + 0.2 cos(k pi)
                         % 4: B(k) = 0.9 + 0.1 cos(2 k pi)
                         % 5: B(k) = 0.9 + 0.1 cos(4 k pi)
                         % 6: B(k) = 0.8 + 0.2 cos(2 k pi)
                         
    frac_step =  2^(-8);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%