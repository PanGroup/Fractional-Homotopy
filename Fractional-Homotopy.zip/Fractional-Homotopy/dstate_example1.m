    % -------------------------------------------------------------------------
    %
    %  Descriptions:
    %   Differential equations
    %  Author:
    %   Binfeng Pan (Northwestern Polytechnical University, P.R. China)
    %   Email: panbinfeng@nwpu.edu.cn
    %
    % -------------------------------------------------------------------------

function dx = dstate_example1(t,x, p)
    q=p(1);
    s = 0.5*x(6);
    if(s<-1*(1-q))
        u1=-1;
    else
        if(s>1*(1-q))
            u1=1;
        else
            u1=s/(1-q);
        end
    end

    dx(1)  = -x(2);
    dx(2)  = x(3);
    dx(3)  = -q*pow(x(2),5)+u1;
    dx(4)  = 0;
    dx(5)  = x(4)+q*5*x(6)*pow(x(2),4);
    dx(6)  = -x(5);
    dx = dx(:);
end

function value = pow(t,x)
    value = t^x;
end