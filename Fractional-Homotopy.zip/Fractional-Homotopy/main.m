    % -------------------------------------------------------------------------
    %
    %  Descriptions:
    %   Main file
    %  Author:
    %   Binfeng Pan (Northwestern Polytechnical University, P.R. China)
    %   Email: panbinfeng@nwpu.edu.cn
    %
    % -------------------------------------------------------------------------

    clear all
    
    Params_Setting
    %% Numerical accuracy setting
    atol = solver_tol;
 

    %% Initial guess
    x0 = Unknowns_guess;

    %% Homotopy parameter lower and upper boundaries
    L_0 = 0.0;
    L_1 = 1;

    file_name = sprintf('data_%s.txt',datestr(now,29));
    
    [x_r, param_r,errorflag] = ...
        arclength_continuation('func',file_name, L_0,L_1,x0,atol,max_norm_x); 


    


