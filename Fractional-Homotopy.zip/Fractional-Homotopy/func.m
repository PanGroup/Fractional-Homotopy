    % -------------------------------------------------------------------------
    %
    %  Descriptions:
    %   Main file
    %  Author:
    %   Binfeng Pan (Northwestern Polytechnical University, P.R. China)
    %   Email: panbinfeng@nwpu.edu.cn
    %
    % -------------------------------------------------------------------------
    function f = func(X0,Param)
        Params_Setting;
        
        y0 =[x1_0, x2_0, x3_0, X0(1), X0(2),X0(3)]';

        frac_derivative = ones(ODE_DIM,1);
        
        %% B(kappa)
        switch B_beta_flag
            case 1
                B_beta  = 1;
            case 2
                B_beta_flag = 0.9+0.1*cos(pi*Param);
            case 3
                B_beta_flag = 0.8+0.2*cos(pi*Param);
            case 4
                B_beta_flag = 0.9+0.1*cos(2*pi*Param);  
            case 5
                B_beta_flag = 0.9+0.1*cos(4*pi*Param);   
            case 6
                B_beta_flag = 0.8+0.2*cos(2*pi*Param);                    
            otherwise
                disp('not defined!')
                return;
        end

            
        frac_derivative(1:3) = B_beta_flag;
        
        if frac_int_flag == 1   % fractional order integration
           [ts,ys] = FDE_PI12_PC(frac_derivative,'dstate_example1',0,X0(4),y0,frac_step,Param);
        else                    % integer order integration by rk45
            timespan = [0,X0(4)];
            options = odeset('RelTol',1e-10,'AbsTol',1e-10,'InitialStep',0.001,'MaxStep',0.1);
            [ts,ys]  = ode45(@(t,y) dstate_example1(t,y,Param),timespan, y0,options);
        end
        ys = ys';
        yf = ys(end,:);
  
        s = 0.5*yf(6);
        if(s<-1*(1-Param))
            u1=-1;
        else
            if(s>1*(1-Param))
                u1=1;
            else
                u1=s/(1-Param);
            end
        end
        f   = zeros(Unknowns_Dim,1);
        f(1) = yf(1) - x1_f;
        f(2) = yf(2) - x2_f;
        f(3) = yf(3) - x3_f;
        f(4) = yf(6)*u1 - 1 - (1-Param)*u1^2;

    end





