% -------------------------------------------------------------------------
%
%  Descriptions:
%   Path following by arc-length continuation.
%  Author:
%   Binfeng Pan (Northwestern Polytechnical University, P.R. China)
%   Email: panbinfeng@nwpu.edu.cn
%
% -------------------------------------------------------------------------

function [x_return,Param_return,errorflag] = arclength_continuation(fun_name,file_name,Param_0,Param_1,x0,solver_tol,max_norm_x)

    % First, set the default parameters if necessary
    x_return = 0;
    Param_return=0;
    errorflag = 0;   
    
    epsilon =  sqrt(eps);    
    ArcLenParam.atol = solver_tol;
    ArcLenParam.ds  = 0.001;
    ArcLenParam.max_iter = 900000000;
    ArcLenParam.max_corr =40;
    
    % extract number and norm of unknowns
    N = length(x0);
    norm_x = norm(x0);
    % maximum value of norm_x to avoid that the intermediate solution goes
    % to infinity, which may have to be defined according to 
    %
    max_xn=max_norm_x;     
    
    % Simulation datas will be written into a single file
    fid_sim = fopen(file_name,'a+t');

    % set counter on number of points identified along curve
    count_pts = 0;
    
    % First, solve system at initial steady state
    Options_fsolve  = optimset('TolX',1e-8','TolFun',1e-8,'MaxIter',800,...
            'MaxFunEvals',1000,'FunValCheck ','on' ,'LargeScale','off',...
            'Algorithm','trust-region-dogleg','Display','iter',...%trust-region-dogleg trust-region-reflective
            'PrecondBandWidth',1);
    [x,f] = fsolve(fun_name,x0,Options_fsolve,Param_0);
    % Compute Jacobian of function from finite differences
    Jac = ac_calc_Jac(fun_name,x,Param_0,f,epsilon,ArcLenParam.ds);
    % store result at first point along solution curve
    x_c(:,1) = x;

    % parameter space
    lambda = 0;
    Param = (1-lambda)*Param_0 + lambda*Param_1;

    % record/plot first data
    temp_x = [count_pts,ArcLenParam.ds,Param,x(1:N)'];
    fprintf(fid_sim,'%4.11f %4.11f %4.11f %4.11f %4.11f %4.11f %4.11f \n',temp_x);
    figure(2);
    plot(Param,x(N),'ro');
    hold on
        
    % defaulty setting of sevearl parameters     
    count_pts = count_pts + 1;  % increment counter
    Param_old1 = Param_0;
    Param_old2 = Param_0;
    x_old = x;  
    x_old2=x;
    lambda_old = lambda;
    lambda_old2=lambda;
    f_old = f;
    f_old2 = f;
    c_rand = rand(1,N+1); 

    % Now, perform iterations along arclength continuation
    icomplete_arclength = 0;
    icorr_OK=0;
    nCount =1;
    nx6 = 0;
    
    for iter=1:ArcLenParam.max_iter 
    % check to see if lambda exceeds 1, so that
    % we can stop
    if(lambda >= 1)
        icomplete_arclength = 1;
        break;
    end
    norm_x = norm(x);
    
    if nCount == 1
        % adaptive arclength step
        ArcLenParam.ds = 2*ArcLenParam.ds;%ds_default;norm_x/100
           
        if ArcLenParam.ds > norm_x/20
           ArcLenParam.ds = norm_x/20;
        end
        bound = norm_x/10;               
    end
    
   df_dlambda = ac_calc_df_dlambda(fun_name,x,lambda,Param_0,Param_1,f,epsilon,ArcLenParam.ds);
   
   % construct matrix for solving dz/ds
   A = zeros(N+1,N+1);
   A(1:N,1:N) = Jac;
   A(1:N,N+1) = df_dlambda;
   A(N+1,1:N+1) = c_rand;
  
   % solve for dz/ds
   b = zeros(N+1,1); b(N+1) = 1;
   v = A\b;
   dz_ds = v / norm(v,2);
   
   % make sure that we move in same direction along curve
   % as previously
   dz_old = zeros(N+1,1);
   dz_old(1:N) = x - x_old2;
   dz_old(N+1) = lambda - lambda_old2;
  if norm(dz_old) ==0 %|| count_pts== 0
       if dz_ds(N+1) <0
           dz_ds = -dz_ds;
       end
   else
       if(dot(dz_ds,dz_old) < 0 )
           dz_ds = -dz_ds;
       end
   end   
   
   % Now, use explicit Euler predictor to find predict new value
   % along curve
   x_old = x;  lambda_old = lambda;
   f_old = f;
   x = x + dz_ds(1:N)*ArcLenParam.ds;
   nx6 = 0;
  for kkk=1:N
         if abs(imag(x(kkk)))>0 || isnan(x(kkk))
               nx6 = 1;
               break;
         end
   end
           
   if norm(x) > max_xn || nx6 == 1 || (abs(abs(x_old(N)) - abs(x(N))) > bound)
           icorr_OK = 0;
   else
       lambda = lambda + dz_ds(N+1)*ArcLenParam.ds;
       Param = (1-lambda)*Param_0 + lambda*Param_1;
       if abs(Param) > 2
               icorr_OK = 0;
       else    
       f = feval(fun_name,x,Param);
       % Now, perform corrector iterations
       icorr_OK = 0;
       
       % form fixed augmented Jacobian maitrx by replacing
       % last row of A with dz_ds
       A(N+1,:) = dz_ds';
       % as this matrix is fixed for each corrector iteration,
       % perform LU decomposition
       [L,U,P] = lu(A);
       if rank(A(1:N,1:N)) < N
           rank(A(1:N,1:N))
           disp('limit point!')
       end
       for k_corr = 1:ArcLenParam.max_corr
           % check for convergence
           if(norm(f,2) <= ArcLenParam.atol )
               icorr_OK = 1;
               break;
           end
           % get delta_z
           nn = [-f;0];
           v = L\(P*nn);
           delta_z= U\v;
           if abs(imag(delta_z(N))) > 0
               icorr_OK = 0;
                break;
           end
           
          x = x + delta_z(1:N);
          nx6 = 0;
          lambda = lambda + delta_z(N+1);
           % get new function value
          Param = (1-lambda)*Param_0 + lambda*Param_1;   
          for kkk=1:N
                if abs(imag(x(kkk)))>0 || isnan(x(kkk))
               nx6 = 1;
               break;
                 end
          end

            
           if norm(x) > max_xn || nx6 == 1 || Param <  0 || (abs(abs(x_old(N)) - abs(x(N))) > bound) 
                   icorr_OK = 0;
                   break;
           end                

           f = feval(fun_name,x,Param);
       end
   end    
   end
   if(icorr_OK==0)
       if nCount >12 || ArcLenParam.ds < 1.0e-12
           f
           max_xn = 1
           return;
       else
           lambda=lambda_old;
           x = x_old;
           f=f_old;
           Param = (1-lambda)*Param_0 + lambda*Param_1;
           Jac = ac_calc_Jac(fun_name,x,Param,f,epsilon,ArcLenParam.ds);
           ArcLenParam.ds = ArcLenParam.ds/4;
           nCount = nCount+1;
       end
   elseif  icorr_OK==1     
        x_old2 = x_old;
        lambda_old2=lambda_old;
        f_old2 = f_old;

       % Compute new Jacobian of function from finite differences
       Jac = ac_calc_Jac(fun_name,x,Param,f,epsilon,ArcLenParam.ds);   
       % store results
       % for memory saving, only the final value saved
       x_c(:,1) = x;
       lambda_c(:,1) = lambda;
       Param_c(:,1) = Param;
       fnorm_c(:,1) = norm(f,inf);
       Param_old2 = Param_old1;
       Param_old1 = Param;
       temp_x = [count_pts,ArcLenParam.ds,Param,x(1:N)'];
       sprintf('%4.11f %4.11f %4.11f %4.11f %4.11f %4.11f %4.11f \n',temp_x)
     
       if Param > Param_1   || Param< 0
           errorflag = 666
           return;
       end
       
       count_pts = count_pts + 1;  % increment counter
       
       nCount = 1;
      fprintf(fid_sim,'%4.11f %4.11f %4.11f %4.11f %4.11f %4.11f %4.11f \n',temp_x);
      figure(2);
      plot(Param,x(N),'ro');
      hold on
      pause(0.001);
   end
end
    fclose(fid_sim);
return;
% 

function Jac = ac_calc_Jac(fun_name,x,theta,f,epsilon,ds)

   if ds < 0.05
       Jac = ac_calc_Jac2(fun_name,x,theta,f,epsilon);
   else
       Jac = ac_calc_Jac1(fun_name,x,theta,f,epsilon);
   end
return;

function df_dlambda = ...
    ac_calc_df_dlambda(fun_name,x,lambda,Param_0,Param_1,f,epsilon,ds)
    
if ds < 0.05
       df_dlambda = ac_calc_df_dlambda2(fun_name,x,lambda,Param_0,Param_1,f,epsilon);
   else
       df_dlambda = ac_calc_df_dlambda1(fun_name,x,lambda,Param_0,Param_1,f,epsilon);
   end

return;

function Jac = ac_calc_Jac1(fun_name,x,theta,f,epsilon)

    N = length(x);  Jac = zeros(N,N);
    
    x_new = zeros(N,1);
    f_new = zeros(N,1);
    parfor k=1:N
        x_new = x;  
        x_new(k) = x(k) + epsilon;
        f_new = feval(fun_name,x_new,theta);
        Jac(:,k) = (f_new-f)/epsilon;
    end
return;



%--------------------------------------------------------------
% This routine uses finite differences to evaluate the partials
% of the function with respect to lambda.
function df_dlambda = ...
    ac_calc_df_dlambda1(fun_name,x,lambda,Param_0,Param_1,f,epsilon);
    
    Param0 = (1-lambda)*Param_0 + lambda*Param_1;

    lambda_new = lambda + epsilon;
    Param_new = (1-lambda_new)*Param_0 + lambda_new*Param_1;
    f_new = feval(fun_name,x,Param_new);
    df_dlambda = (f_new-f)/epsilon;

return;
%--------------------------------------------------------------
%This routine uses finite differences to evaluate the Jacobian
%matrix of the function.
function Jac = ac_calc_Jac2(fun_name,x,theta,f,epsilon);

    N = length(x);  Jac = zeros(N,N);
    
    x_new = zeros(N,1);
    f_new1 = zeros(N,1);
    f_new2 = zeros(N,1);
    f_newm1 = zeros(N,1);
    f_newm2 = zeros(N,1);  
    parfor k=1:N
        x_new = x;  
        x_new(k) = x(k) + epsilon;
        f_new1 = feval(fun_name,x_new,theta);
        x_new(k) = x(k) + 2*epsilon;
        f_new2 = feval(fun_name,x_new,theta);
        x_new(k) = x(k) - epsilon;
        f_newm1 = feval(fun_name,x_new,theta);
        x_new(k) = x(k) - 2*epsilon;
        f_newm2 = feval(fun_name,x_new,theta);        
        Jac(:,k) = (-f_new2+8*f_new1-8*f_newm1+f_newm2)/(12*epsilon);
    end
    
return;



%--------------------------------------------------------------
% % This routine uses finite differences to evaluate the partials
% % of the function with respect to lambda.
function df_dlambda = ...
    ac_calc_df_dlambda2(fun_name,x,lambda,Param_0,Param_1,f,epsilon);
    
    Param0 = (1-lambda)*Param_0 + lambda*Param_1;

    lambda_new = lambda + epsilon;
    Param_new = (1-lambda_new)*Param_0 + lambda_new*Param_1;
    f_new1 = feval(fun_name,x,Param_new);
    lambda_new = lambda + 2*epsilon;
    Param_new = (1-lambda_new)*Param_0 + lambda_new*Param_1;
    f_new2 = feval(fun_name,x,Param_new);

     lambda_new = lambda - epsilon;
    Param_new = (1-lambda_new)*Param_0 + lambda_new*Param_1;
    f_newm1 = feval(fun_name,x,Param_new);
    lambda_new = lambda -  2*epsilon;
    Param_new = (1-lambda_new)*Param_0 + lambda_new*Param_1;
    f_newm2 = feval(fun_name,x,Param_new);
    df_dlambda = (-f_new2+8*f_new1-8*f_newm1+f_newm2)/(12*epsilon);

return;
